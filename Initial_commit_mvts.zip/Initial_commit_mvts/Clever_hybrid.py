import Clever_cluster
import Clever_ranking
from numpy import linalg as la
import pandas as pd


def clever_hybrid(DCPC, col, k):
    """
    Clever hybrid utilizes both the ranking part of Clever Rank and the clustering part of
    Clever Cluster for variable subset selection

    :param data_path: path to the loadings data
    :param k: No. of desired or required variables in Truncated data
    :return: Gives the selected top ranked variable indices
    """
    # DCPC, col = Sample_mvts.Compute_DCPCS(data_path)

    clusters = []
    selected_var = []
    colmn, labels = Clever_cluster.clever_cluster(DCPC, col, 15)
    for s in range(k):
        cluster_ele = []
        for ind, val in enumerate(labels):
            if s == val:
                cluster_ele.append(ind)
            else:
                pass
        clusters.append(cluster_ele)
    for x in clusters:
        if len(x) > 1:
            pair = []
            for ind in DCPC.columns:
                if int(ind) in x:
                    val = la.norm(DCPC[ind])
                    pair.append([ind, val])
            Clever_ranking.Sort(pair)
            selected_var.append(pair[0][0])
        else:
            selected_var.append(x[0])
    pair = []
    final_selected_var = []
    for i, sv in enumerate(selected_var):
        val = la.norm(DCPC[str(sv)])
        pair.append([str(sv), val])
    Clever_ranking.Sort(pair)
    for ind, x in enumerate(pair):
        final_selected_var.append(x[0])
    for ind, close in enumerate(final_selected_var):
        final_selected_var[ind] = col[int(close)]
    return final_selected_var


"""
data_path = 'C:/Users/Krishna Rukmini/Downloads/partition1_instances/partition1_instances (1).tar/partition1/FL/'
final = clever_hybrid(data_path, 15)
print(final)


data = pd.read_csv("../Initial_commit_mvts/Data/DCPC_CSV.csv", sep='\t')
data.drop(["Unnamed: 0"], axis=1, inplace=True)
col = {1 : 'TOTUSJH', 2 : 'TOTBSQ', 3 : 'TOTPOT', 4 : 'TOTUSJZ',
        5 : 'ABSNJZH', 6 : 'SAVNCPP', 7 : 'USFLUX', 8 : 'TOTFZ',
        9 : 'MEANPOT', 10 : 'EPSZ', 11 : 'MEANSHR', 12 : 'SHRGT45',
        13 : 'MEANGAM', 14 : 'MEANGBT', 15 : 'MEANGBZ', 16 : 'MEANGBH',
        17 : 'MEANJZH', 18 : 'TOTFY', 19 : 'MEANJZD', 20 : 'MEANALP',
        21 : 'TOTFX', 22 : 'EPSY', 23 : 'R_VALUE', 24 : 'EPSX'}
selected_var = clever_hybrid(data, col, 15)
print(selected_var)

hybrid_univariate_df = pd.DataFrame()
hybrid_univariate_df['rank_list_fss'] = selected_var
hybrid_univariate_df.to_csv("../Initial_commit_mvts/Results/hybrid_univariate.csv", sep='\t')

"""