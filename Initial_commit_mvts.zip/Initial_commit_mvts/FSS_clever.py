import Sample_mvts
import Clever_ranking
import Clever_cluster
import Clever_hybrid
import pandas as pd


K = int(input("enter the number of variables required: "))
choice = 0
data_path = r'../Initial_commit_mvts/Data/Cleaned_data/'
DCPC, col = Sample_mvts.Compute_DCPCS(data_path)
while choice != 4:
    choice = int(input("select the algorithm from the below list \n"
                       " Clever ranking - 1 \n "
                       "Clever cluster - 2 \n "
                       "Clever hybrid - 3 \n "
                       "Exit - 4 \n"
                       "Enter your choice: "))
    if choice == 1:
        selected_K = Clever_ranking.Clever_rank(DCPC, col, 24)
        print("Cluster Ranking Variables")
        print(selected_K)
        ranking_univariate_df = pd.DataFrame()
        ranking_univariate_df['rank_list_fss'] = selected_K
        ranking_univariate_df.to_csv("../Initial_commit_mvts/Results/ranking_univariate.csv", sep='\t')
    elif choice == 2:
        col, labels = Clever_cluster.clever_cluster(DCPC, col, K)
        print("Cluster Cluster Variables")
        print(col)
        clustering_univariate_df = pd.DataFrame()
        clustering_univariate_df['rank_list_fss'] = col
        clustering_univariate_df.to_csv("../Initial_commit_mvts/Results/clustering_univariate.csv", sep='\t')
    elif choice == 3:
        final = Clever_hybrid.clever_hybrid(DCPC, col, K)
        print("Cluster Hybrid Variables")
        print(final)
        hybrid_univariate_df = pd.DataFrame()
        hybrid_univariate_df['rank_list_fss'] = final
        hybrid_univariate_df.to_csv("../Initial_commit_mvts/Results/hybrid_univariate.csv", sep='\t')
    else:
        pass
