import pandas as pd
from numpy import linalg as LA


def Sort(sub_li):
    """
    Sort the list of lists based on the second element
    :param sub_li: list of lists
    :return: returns the sorted list of lists
    """
    sub_li.sort(key=lambda x: x[1], reverse=True)
    return sub_li


# Clever Rank
def Clever_rank(DCPC, col, k):
    """
    CLeVer Rank algorithm - calculates L-square norm values for each variable and returns the top K variables
    :param data_path: path to the loadings data
    :param k: No. of desired or required variables in Truncated data
    :return: Gives the selected top ranked variable indices
    """
    pair = []
    selected_var = []
    #DCPC, col = Sample_mvts.Compute_DCPCS(data_path)

    for ind in DCPC.columns:
        val = LA.norm(DCPC[ind])
        pair.append([ind, val])
    data = pd.DataFrame(pair)
    data.to_csv("../Initial_commit_mvts/Data/Clever_rank.csv", sep='\t')
    Sort(pair)
    selected_var_dist = pair[:k]
    for ind, close in enumerate(selected_var_dist):
        selected_var_dist[ind][0] = col[close[0]]
        selected_var.append(selected_var_dist[ind][0])
    return selected_var



"""
data_path = 'C:/Users/Krishna Rukmini/Downloads/partition1_instances/partition1_instances (1).tar/partition1/FL/'
selected_K = Clever_rank(data_path, 15)
print(selected_K)
"""
