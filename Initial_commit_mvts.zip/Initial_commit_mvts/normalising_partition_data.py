import pandas as pd
import os

partition_1_df = pd.read_csv("/content/drive/MyDrive/partition_1_df.csv", sep='\t')
partition_2_df = pd.read_csv("/content/drive/MyDrive/partition_2_data.csv", sep='\t')

partition_1_df.drop("Unnamed: 0", axis=1, inplace=True)
partition_2_df.drop("Unnamed: 0", axis=1, inplace=True)

from sklearn.preprocessing import MinMaxScaler


def List_Of_Files(dir_name):
    listoffiles = [x[2] for x in os.walk(dir_name)]
    return listoffiles


def files_data(file, path, dir):
    data = pd.read_csv(path + dir + '/' + file, sep='\t')
    data.drop('Unnamed: 0', axis=1, inplace=True)
    # print(data.head())
    y2 = data['flare_type']
    data.drop('flare_type', axis=1, inplace=True)
    return data, y2


def normalize_data(partition1, partition2, path):
    """

    """


X1 = partition1.copy()
y1 = partition1['flare_type']
X1.drop('flare_type', axis=1, inplace=True)

X2 = partition2.copy()
y2 = partition2['flare_type']
X2.drop('flare_type', axis=1, inplace=True)

partition_1_2_df = pd.concat([X1, X2], axis=0)
scaler = MinMaxScaler()
scaler.fit(partition_1_2_df)

F_T = ["FL", "NF"]
count = 0
for dir in F_T:
    files = List_Of_Files(path + dir + '/')
    print(files)
    for file in files[0]:
        x_data, y_data = files_data(file, path, dir)
        partition_2_nor_df = scaler.transform(x_data)
        partition_data = pd.DataFrame(partition_2_nor_df, columns=x_data.columns)
        partition_data['flare_type'] = list(y_data)
        partition_data.to_csv(path + dir + '/' + file, sep='\t')
        count += 1
        print(count)

# normalize_data(partition_1_df,partition_2_df, path = "../Initial_commit_mvts/Data/Cleaned_data_partition_2/")

# normalize_data(partition_1_df,partition_2_df, path = "../Initial_commit_mvts/Data/Cleaned_data/")