import matplotlib.pyplot as plt
from pandas import read_csv
import seaborn as sns
import Data_cleaning


def DCPCS_plt(path):
    """
    Bar plot for DCPCs
    :param path: Path to the sample file folder
    :return: None (shows the plot)
    """
    x = read_csv(path, sep="\t")
    a_list = x['0'].tolist()
    New_Colors = ['green', 'blue', 'purple', 'brown', 'teal']
    plt.bar(x=range(len(a_list)), height=a_list, color=New_Colors)
    plt.show()


def Correlation_heatmap(path):
    """
    Correlation_matrix representation as heatmap
    :param path: Path to the sample file folder
    :return:  None (shows the plot)
    """
    data = Data_cleaning.MTSDataset(path, 24).load_clean_data()
    sns.heatmap(data.corr(), cmap='Blues')
    plt.show()


def cluster_rank_plot(path):
    """
        Bar plot for DCPCs
        :param path: Path to the sample file folder
        :return: None (shows the plot)
        """
    x = read_csv(path, sep="\t")
    New_Colors = ['green', 'blue', 'purple', 'brown', 'teal']
    plt.bar(x=x['0'], height=x['1'], color=New_Colors)
    plt.show()


cluster_rank_plot("../Initial_commit_mvts/Data/Clever_rank.csv")
DCPCS_plt(r"C:\Users\Krishna Rukmini\Downloads\Variance\VarianceM1.0@265_Primary_ar115_s2010-08-06T06_36_00_e2010-08-06T18_24_00.csv")
Correlation_heatmap(r'C:\Users\Krishna Rukmini\Downloads\partition1_instances\partition1_instances (1).tar\partition1\FL\M1.0@265_Primary_ar115_s2010-08-06T06_36_00_e2010-08-06T18_24_00.csv')
Correlation_heatmap(r'C:\Users\Krishna Rukmini\Downloads\partition1_instances\partition1_instances (1).tar\partition1\FL\M1.0@265_Primary_ar115_s2010-08-06T07_36_00_e2010-08-06T19_24_00.csv')
Correlation_heatmap(r'C:\Users\Krishna Rukmini\Downloads\partition1_instances\partition1_instances (1).tar\partition1\NF\B1.0@13_Primary_ar10_s2010-05-02T23_12_00_e2010-05-03T11_00_00.csv')


# from sklearn.cluster import KMeans

# y = read_csv(r"C:\Users\Krishna Rukmini\Downloads\DCPC\name.csv")
# print(y.columns)
# print(y.drop(columns=['Unnamed: 0'], inplace=True))
# print(y)
# l = y['labels']
# y.drop(columns=['labels'], inplace=True)
# print(y)
# for x in range(20):
#    kmeans = KMeans(n_clusters=15, random_state=0).fit(y)
# labels = kmeans.labels_
# y_kmeans = kmeans.predict(y)
# plt.scatter(y[:]['0'], y[:]['1'], c=y_kmeans, cmap='viridis')
# centers = kmeans.cluster_centers_
# plt.scatter(centers[:, 0], centers[:, 1], c='black', alpha=0.5)
# plt.title('K-means Clustering with 2 dimensions')
# plt.show()
