import pandas as pd
import numpy as np


def drop_timestamp(data):
    """
    Drops the timestamp column
    :param data: dataframe from which you would require to drop timestamp column
    :return: dataframe without timestamp column
    """
    new_df = data.drop('Timestamp', axis=1)
    return new_df


class MTSDataset:

    def __init__(self, data_path, n):
        """

        :param data_path: file path of partition folder
        :param n: features taken into consideration
        """
        self.data_path = data_path
        self.n = n

    def load_clean_data(self):
        """
        load data from partition
        :return: Data from the partition
        """
        sample_file = pd.read_csv(self.data_path, sep='\t')
        data = pd.DataFrame(sample_file)
        data = drop_timestamp(data)
        mts_clean_data = data.T.head(self.n).T
        mts_clean_data.replace([np.inf, -np.inf], np.nan, inplace=True)
        return mts_clean_data.ffill().bfill()

# def main():
#   mt = MTSDataset(
#        r"C:\Users\Krishna Rukmini\PycharmProjects\SummerCodeSprint\mvts_fss_krp\Initial_commit_mvts\partition1\FL\M1.0@265_Primary_ar115_s2010-08-06T06_36_00_e2010-08-06T18_24_00.csv",
#        24)

#   print(mt.load_clean_data())


# if __name__ == "__main__":
#     main()
