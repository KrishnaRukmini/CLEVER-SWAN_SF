import pandas as pd
from pandas import DataFrame
import numpy as np
from scipy import linalg
import os
import Data_cleaning


def transpose(data: DataFrame) -> DataFrame:
    """
    Function to do transpose of dataframe
    :param data: dataframe to be transposed
    :return: dataframe
    """
    return data.T


def SVD(ndf: DataFrame):
    """
    SVD - Singular value Decomposition
    :param ndf: Dataframe
    :return: Singular Vectors, Variance
    """
    U, s, Vh = linalg.svd(ndf)
    return U, s, Vh


def percent_variance(var):
    """
    variances percentages
    :param var: variances (singular or eigen values)
    :return: list of variance percentages
    """
    percentv = []
    total = np.sum(var)
    for p in var:
        val = 100 * (p / total)
        percentv.append(val)
    return percentv


def num_var_lessthan_threshold(percentv, threshold):
    """
    gets the number of variables whose sum is less than the threshold value chosen
    :param percentv: List of variable percentages
    :param threshold: threshold value ( 70% - 90% )
    :return: count - sum of p variables percentages and len(p) - no. of variables
    """
    count = 0
    p = []
    for indx, x in enumerate(percentv):
        if count <= threshold:
            count = count + x
            p.append(indx)
    return count, len(p)


def List_Of_Files(dir_name):
    """
    List of files in the given directory
    :param dir_name: path of the directory
    :return: A list of files in the directory
    """
    listOfFile = [x[2] for x in os.walk(dir_name)]
    return listOfFile[0]


def File_name(file_name):
    """

    :param file_name: File name
    :return: file name with file type cropped
    """
    return file_name[:-4]


def data_columns(data):
    """
    data columns or variables stored in a dictionary
    :param data: data frame is given as an input
    :return: returns a dictionary of variables
    """
    dictn_varibles = {}
    col = list(data.columns)
    for indx, value in enumerate(col):
        dictn_varibles[indx] = value
    return dictn_varibles


def loadings_files(loadings_path, load, file_name):
    """
    Saving loadings to a csv file
    :param loadings_path: path to save the file
    :param load: loadings (singular vectors or eigen vectors)
    :param file_name: File name
    :return: returns the dataframe
    """
    load.to_csv(loadings_path + file_name + '.csv', sep="\t", index=False)
    return load


def loadings_data_load(data_path: str) -> DataFrame:
    """
    To read the loading files stored
    :param data_path: path to the directory
    :return: returns a dataframe
    """
    sample_file = pd.read_csv(data_path, sep='\t')
    dataframe = pd.DataFrame(sample_file)
    return dataframe


def Compute_DCPCS(path):
    """
    Computes principal components (PCs) and common principal components (DCPCs)
    :param path: path to the main directory
    :return: returns DCPCs
    """

    count = 0
    f_t = ["FL", "NF"]
    P_values_each_file = pd.DataFrame(columns=["percentvar", 'no_of_variables'])
    loadings_path = '../Initial_commit_mvts/Data/Loadings/'

    for ft in f_t:
        list_of_files = List_Of_Files(path+ft)
        print(list_of_files[0])
        for file in list_of_files:
            count += 1
            print(count)
            file_name = File_name(file)
            data = pd.read_csv(path+ft+'/'+file, sep='\t')
            data.drop(["Unnamed: 0", "flare_type"], axis=1, inplace=True)
            corrMatrix = data.corr()
            if corrMatrix.isnull().values.any():
                print(file_name)
            else:
                # corrMatrix = corrMatrix.fillna(0)
                U, s, Vh = SVD(corrMatrix)
                Loadings = U
                Variance = s
                prcnt_var = percent_variance(Variance)
                to_append = list(num_var_lessthan_threshold(prcnt_var, 90))
                a_series = pd.Series(to_append, index=P_values_each_file.columns)
                P_values_each_file = P_values_each_file.append(a_series, ignore_index=True)
                loadings_files(loadings_path, pd.DataFrame(Loadings), file_name)
    data_col = data_columns(data)
    loadings_path = '../Initial_commit_mvts/Data/Loadings/'
    list_of_files = List_Of_Files(loadings_path)
    p = int(max(P_values_each_file['no_of_variables']))
    H_matrix = pd.DataFrame(index=range(24), columns=range(24))
    H_matrix[:] = 0
    count = 0
    for file in list_of_files:
        count += 1
        data = loadings_data_load(loadings_path + file)
        Loading = data[:p][:]
        Loading_T = Loading.T
        H_matrix = np.matrix(np.add(H_matrix, np.matmul(np.asarray(Loading_T), np.asarray(Loading))), dtype=float)
        print(count)
    new_u, new_s, new_Vh = SVD(H_matrix)
    DCPC = pd.DataFrame(new_u[:p][:])
    DCPC.to_csv(r"C:\Users\Krishna Rukmini\PycharmProjects\SummerCodeSprint\mvts_fss_krp\Initial_commit_mvts\Data\DCPC_CSV.csv", sep='\t')
    return DCPC, data_col



