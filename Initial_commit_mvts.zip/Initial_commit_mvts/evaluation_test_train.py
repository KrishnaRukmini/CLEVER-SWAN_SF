import pandas as pd
from sklearn.svm import LinearSVC
from sklearn.metrics import confusion_matrix
import numpy as np
import os


def TSS(TP, FP, FN, TN):
    """

    Calculate TSS for evaluate
    :param TP: True Positive value from confusion matrix
    :param FP: False Positive value from confusion matrix
    :param FN: False Negative value from confusion matrix
    :param TN: True Negative value from confusion matrix
    :return: tss score
    """
    val1 = (TP + FN)
    val2 = (FP + TN)
    tss = float((TP / val1) - (FP / val2))
    return tss


def HSS(tp, fp, fn, tn):
    """

    Calculate HSS for evaluate
    :param tp: True Positive value from confusion matrix
    :param fp: False Positive value from confusion matrix
    :param fn: False Negative value from confusion matrix
    :param tn: True Negative value from confusion matrix
    :return: hss score
    """
    numer = 2 * ((tp * tn) - (fn * fp))
    denom = ((tp + fn) * (fn + tn)) + ((tp + fp) * (fp + tn))
    hss = (numer / denom) if denom != 0 else 0
    return hss


def load_normalised_data(partition_dataframe_path):
    """

    Method to load Normalised data
    :param partition_dataframe_path: Normalized data path given as input
    :return: returns dataframe of normalised MVTS data file
    """
    data = pd.read_csv(partition_dataframe_path, sep='\t')
    data.drop("Unnamed: 0", axis=1, inplace=True)
    data.replace([np.inf, -np.inf], np.nan, inplace=True)
    data = data.ffill().bfill()
    return data


def List_Of_Files(path):
    """

    Stores the file names in a list
    :param dir_name: path to the partition folder
    :return: returns a list of files names
    """
    listoffiles = [x[2] for x in os.walk(path)]
    return listoffiles


def undersample_dataframe_prep(normalized_data_path_partition1):
    """

    Prepares data for undersampling (collects the filenames of the data to be used in under sampling).
    :param normalized_data_path_partition1: path to the normalized partition1 data
    :return: returns the dataframe having the file names and labels of the corresponding file
    """
    listoffiles = List_Of_Files(normalized_data_path_partition1)
    undersample_df = pd.DataFrame()
    flare_class = []
    file_names = []
    for i in [1, 2]:
        for x in listoffiles[i]:
            file_names.append(x)
            flare_class.append(x[0])
    undersample_df['file_names'] = file_names
    undersample_df['flare_class'] = flare_class
    return undersample_df


def under_sampling(dataf, label):
    """

    Undersampling implementation - uses sampler.py file
    :param dataf: undersampled data frame
    :param label: label variable name
    :return: returns the under sampled data of the file names
    """
    from sampler import Sampler
    data = dataf.copy()
    sd = Sampler(data, label)
    sam = sd.sample(
        desired_ratios={'M': -1, 'X': -1, 'B': 0.0013444871, 'C': 0.0015155005974877998, 'F': 0.014203093972403586})
    return sam


def svm_dataframe(normalized_data_path_partition1, file_names):
    """

    Dataframe with the data to be passed to the model for training
    :param normalized_data_path_partition1: path to the normalized partition1 data
    :param file_names: filenames that are selected by the samper
    :return: dataframe ready to be passed for training
    """
    data = pd.DataFrame()
    for file in file_names:
        if file[0] in ['M', 'X']:
            data_df = pd.read_csv(normalized_data_path_partition1 + 'FL/' + file, sep='\t')
            data_df.drop("Unnamed: 0", axis=1, inplace=True)
            data = pd.concat([data, data_df], axis=0)
        else:
            data_df = pd.read_csv(normalized_data_path_partition1 + 'NF/' + file, sep='\t')
            data_df.drop("Unnamed: 0", axis=1, inplace=True)
            data = pd.concat([data, data_df], axis=0)
    data.replace([np.inf, -np.inf], np.nan, inplace=True)
    data = data.ffill().bfill()
    len(data)
    return data


def multivariate_eval(norm_partition_1_path, normalised_part_2_path, ranking_univariate_path):
    """
    Multivariate evaluation
    :param norm_partition_1_path: path to the normalized partition1 data
    :param normalised_part_2_path: path to the normalized partition2 data
    :param ranking_univariate_path: path to the file having ranked features selected by CLeV er Algorithms
    :return: data frame having the TSS and HSS scores
    """
    dataP2 = load_normalised_data(normalised_part_2_path)
    dataP2['flare_type'].replace({'M': 0, 'X': 0, 'B': 1, 'C': 1, 'F': 1}, inplace=True)
    ranking_univariate_df = pd.read_csv(ranking_univariate_path, sep='\t')
    ranking_univariate_df.drop("Unnamed: 0", axis=1, inplace=True)
    rank_list = list(ranking_univariate_df['rank_list_fss'])
    tss_std_list = []
    hss_std_list = []
    tss_mean_list = []
    hss_mean_list = []
    no_of_features = []
    list_features = rank_list
    ranking_univariate_df.drop("rank_list_fss", axis=1, inplace=True)
    for x in range(len(rank_list)):
        print(list_features)
        tss_std, hss_std, tss_mean, hss_mean = svm_eval_multivariate(norm_partition_1_path, dataP2, list_features)
        no_of_features.append(len(list_features))
        tss_std_list.append(tss_std)
        hss_std_list.append(hss_std)
        tss_mean_list.append(tss_mean)
        hss_mean_list.append(hss_mean)
        list_features.pop()
    ranking_univariate_df['no_of_features'] = no_of_features
    ranking_univariate_df['hss_std'] = hss_std_list
    ranking_univariate_df['tss_std'] = tss_std_list
    ranking_univariate_df['hss_mean'] = hss_mean_list
    ranking_univariate_df['tss_mean'] = tss_mean_list
    return ranking_univariate_df


def svm_eval_multivariate(norm_partition_1_path, dataP2, list_all_variables):
    """
    Multivariate SVM training and testing
    :param norm_partition_1_path: path to the normalized partition1 data
    :param dataP2: normalized partition2 data frame
    :param list_all_variables: List of ranked variables obtained by the FSS Algorithm implemented
    :return: returns TSS and HSS scores
    """
    tss_list = []
    hss_list = []
    list_features = list_all_variables
    undersample_df = undersample_dataframe_prep(norm_partition_1_path)
    for x in range(10):
        X1 = dataP2[list_features]
        y1 = dataP2['flare_type']

        sam = under_sampling(undersample_df, 'flare_class')
        file_names = list(sam['file_names'])
        dataf = svm_dataframe(norm_partition_1_path, file_names)
        dataf['flare_type'].replace({'M': 0, 'X': 0, 'B': 1, 'C': 1, 'F': 1}, inplace=True)
        X = dataf[list_features]
        y = dataf['flare_type']
        lin_svm = LinearSVC()
        lin_svm.fit(X, y)
        y_p2_pred = lin_svm.predict(X1)
        cm = confusion_matrix(y1, y_p2_pred)
        tss_temp = TSS(cm[0][0], cm[0][1], cm[1][0], cm[1][1])
        hss_temp = HSS(cm[0][0], cm[0][1], cm[1][0], cm[1][1])
        tss_list.append(tss_temp)
        hss_list.append(hss_temp)
    tss_std = np.std(np.array(tss_list))
    hss_std = np.std(np.array(hss_list))
    tss_mean = np.mean(np.array(tss_list))
    hss_mean = np.mean(np.array(hss_list))
    return tss_std, hss_std, tss_mean, hss_mean


def univariate_eval(norm_partition_1_path, normalised_part_2_path, ranking_univariate_path):
    """
    Univariate evaluation
    :param norm_partition_1_path: path to the normalized partition1 data
    :param normalised_part_2_path: path to the normalized partition2 data
    :param ranking_univariate_path: path to the file having ranked features selected by CLeV er Algorithms
    :return: data frame having the TSS and HSS scores
    """
    dataP2 = load_normalised_data(normalised_part_2_path)
    dataP2['flare_type'].replace({'M': 0, 'X': 0, 'B': 1, 'C': 1, 'F': 1}, inplace=True)
    ranking_univariate_df = pd.read_csv(ranking_univariate_path, sep='\t')
    ranking_univariate_df.drop("Unnamed: 0", axis=1, inplace=True)

    tss_std_list = []
    hss_std_list = []
    tss_mean_list = []
    hss_mean_list = []
    for rl in ranking_univariate_df['rank_list_fss']:
        print(rl)
        tss_std, hss_std, tss_mean, hss_mean = svm_eval_univariate(norm_partition_1_path, dataP2, rl)
        tss_std_list.append(tss_std)
        hss_std_list.append(hss_std)
        tss_mean_list.append(tss_mean)
        hss_mean_list.append(hss_mean)
    ranking_univariate_df['hss_std'] = hss_std_list
    ranking_univariate_df['tss_std'] = tss_std_list
    ranking_univariate_df['hss_mean'] = hss_mean_list
    ranking_univariate_df['tss_mean'] = tss_mean_list
    return ranking_univariate_df


def svm_eval_univariate(norm_partition_1_path, dataP2, feature_name):
    """
    Univariate SVM training and testing
    :param norm_partition_1_path: path to the normalized partition1 data
    :param dataP2: normalized partition2 data frame
    :param feature_name: variable name from a list of ranked variables obtained by the FSS Algorithm implemented
    :return: returns TSS and HSS scores
    """
    X1 = np.array(dataP2[feature_name])
    y1 = dataP2['flare_type']
    tss_list = []
    hss_list = []

    undersample_df = undersample_dataframe_prep(norm_partition_1_path)

    for x in range(10):
        sam = under_sampling(undersample_df, 'flare_class')
        file_names = list(sam['file_names'])
        dataf = svm_dataframe(norm_partition_1_path, file_names)
        dataf['flare_type'].replace({'M': 0, 'X': 0, 'B': 1, 'C': 1, 'F': 1}, inplace=True)
        X = np.array(dataf[feature_name])
        # X.drop("flare_type", axis=1, inplace=True)
        y = dataf['flare_type']
        lin_svm = LinearSVC()
        lin_svm.fit(X.reshape(-1, 1), y)
        y_p2_pred = lin_svm.predict(X1.reshape(-1, 1))
        cm = confusion_matrix(y1, y_p2_pred)
        tss_temp = TSS(cm[0][0], cm[0][1], cm[1][0], cm[1][1])
        hss_temp = HSS(cm[0][0], cm[0][1], cm[1][0], cm[1][1])
        tss_list.append(tss_temp)
        hss_list.append(hss_temp)
    tss_std = np.std(np.array(tss_list))
    hss_std = np.std(np.array(hss_list))
    tss_mean = np.mean(np.array(tss_list))
    hss_mean = np.mean(np.array(hss_list))
    return tss_std, hss_std, tss_mean, hss_mean



result = multivariate_eval(
    r"../Initial_commit_mvts/Data/Cleaned_norm_data_partition_1/",
    r"..\Initial_commit_mvts\Data/norm_part_2.csv",
    r"..\Initial_commit_mvts\Results/anking_univariate.csv")
result.to_csv(r"..\Initial_commit_mvts\Results/anking_multivariate.csv", sep='\t')

print(result)

result1 = multivariate_eval(
    r"../Initial_commit_mvts/Data/Cleaned_norm_data_partition_1/",
    r"..\Initial_commit_mvts\Data\norm_part_2.csv",
    r"..\Initial_commit_mvts\Results\clustering_univariate.csv")
result1.to_csv(r"..\Initial_commit_mvts\Results\clustering_multivariate.csv", sep='\t')

print(result1)

result2 = multivariate_eval(
    r"../Initial_commit_mvts/Data/Cleaned_norm_data_partition_1/",
    r"..\Initial_commit_mvts\Data\norm_part_2.csv",
    r"..\Initial_commit_mvts\Results\hybrid_univariate.csv")
result2.to_csv(r"..\Initial_commit_mvts\Results\hybrid_multivariate.csv", sep='\t')

print(result2)

result3 = univariate_eval(
    r"..\Initial_commit_mvts\Data\norm_part_1.csv",
    r"..\Initial_commit_mvts\Data\norm_part_2.csv",
    r"..\Initial_commit_mvts\Results\clustering_univariate.csv")
result3.to_csv(r"..\Initial_commit_mvts\Results\clustering_univariate.csv", sep='\t')

print(result3)

result4 = univariate_eval(
    r"..\Initial_commit_mvts\Data\norm_part_1.csv",
    r"..\Initial_commit_mvts\Data\norm_part_2.csv",
    r"..\Initial_commit_mvts\Results\hybrid_univariate.csv")
result4.to_csv(r"..\Initial_commit_mvts\Results\hybrid_univariate.csv", sep='\t')

print(result4)