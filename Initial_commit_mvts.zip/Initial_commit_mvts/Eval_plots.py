import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv("../Initial_commit_mvts/Results/ranking_univariate.csv", sep='\t')
df.drop("Unnamed: 0", axis=1, inplace=True)

plt.errorbar('rank_list_fss', 'tss_mean', yerr='tss_std', data=df, marker='s', capsize=5,
             color='blue', markersize=4, linewidth=1, linestyle='--')
plt.errorbar('rank_list_fss', 'hss_mean', yerr='hss_std', data=df,
             marker='o', capsize=5, color='red', markersize=4, linewidth=1, linestyle='-')
plt.legend()
plt.tick_params(axis='x', rotation=90,labelsize =6)
plt.ylabel("mean Score")
plt.ylim(-0.1, 0.50)
plt.title("example")

plt.savefig('ranking_univariate.png', dpi=500)
plt.show()


df = pd.read_csv("../Initial_commit_mvts/Results/clustering_univariate.csv", sep='\t')
df.drop("Unnamed: 0", axis=1, inplace=True)

plt.errorbar('rank_list_fss', 'tss_mean', yerr='tss_std', data=df, marker='s', capsize=5,
             color='blue', markersize=4, linewidth=1, linestyle='--')
plt.errorbar('rank_list_fss', 'hss_mean', yerr='hss_std', data=df,
             marker='o', capsize=5, color='red', markersize=4, linewidth=1, linestyle='-')
plt.legend()
plt.tick_params(axis='x', rotation=90,labelsize =6)
plt.ylabel("mean Score")
plt.ylim(-0.1, 0.50)
plt.title("example")

plt.savefig('clustering_univariate.png', dpi=500)
plt.show()


df = pd.read_csv("../Initial_commit_mvts/Results/hybrid_univariate.csv", sep='\t')
df.drop("Unnamed: 0", axis=1, inplace=True)

plt.errorbar('rank_list_fss', 'tss_mean', yerr='tss_std', data=df, marker='s', capsize=5,
             color='blue', markersize=4, linewidth=1, linestyle='--')
plt.errorbar('rank_list_fss', 'hss_mean', yerr='hss_std', data=df,
             marker='o', capsize=5, color='red', markersize=4, linewidth=1, linestyle='-')
plt.legend()
plt.tick_params(axis='x', rotation=90,labelsize =6)
plt.ylabel("mean Score")
plt.ylim(-0.1, 0.50)
plt.title("example")

plt.savefig('hybrid_univariate.png', dpi=500)
plt.show()

df1 = pd.read_csv("../Initial_commit_mvts/Results/ranking_multivariate.csv", sep='\t')
df1.drop("Unnamed: 0", axis=1, inplace=True)

plt.errorbar('no_of_features', 'tss_mean', yerr='tss_std', data=df1, marker='s', capsize=5,
             color='blue', markersize=4, linewidth=1, linestyle='--')
plt.errorbar('no_of_features', 'hss_mean', yerr='hss_std', data=df1,
             marker='o', capsize=5, color='red', markersize=4, linewidth=1, linestyle='-')
plt.legend()
plt.tick_params(axis='x', rotation=90,labelsize =6)
plt.ylabel("mean Score")
plt.ylim(-0.1, 0.50)
plt.title("example")

plt.savefig('ranking_multivariate.png', dpi=500)
plt.show()

df = pd.read_csv("../Initial_commit_mvts/Results/clustering_multivariate.csv", sep='\t')
df.drop("Unnamed: 0", axis=1, inplace=True)

plt.errorbar('no_of_features', 'tss_mean', yerr='tss_std', data=df, marker='s', capsize=5,
             color='blue', markersize=4, linewidth=1, linestyle='--')
plt.errorbar('no_of_features', 'hss_mean', yerr='hss_std', data=df,
             marker='o', capsize=5, color='red', markersize=4, linewidth=1, linestyle='-')
plt.legend()
plt.tick_params(axis='x', rotation=90,labelsize =6)
plt.ylabel("mean Score")
plt.ylim(-0.1, 0.50)
plt.title("example")

plt.savefig('clustering_multivariate.png', dpi=500)
plt.show()

df = pd.read_csv("../Initial_commit_mvts/Results/hybrid_multivariate.csv", sep='\t')
df.drop("Unnamed: 0", axis=1, inplace=True)

plt.errorbar('no_of_features', 'tss_mean', yerr='tss_std', data=df, marker='s', capsize=5,
             color='blue', markersize=4, linewidth=1, linestyle='--')
plt.errorbar('no_of_features', 'hss_mean', yerr='hss_std', data=df,
             marker='o', capsize=5, color='red', markersize=4, linewidth=1, linestyle='-')
plt.legend()
plt.tick_params(axis='x', rotation=90,labelsize =6)
plt.ylabel("mean Score")
plt.ylim(-0.1, 0.50)
plt.title("example")

plt.savefig('hybrid_multivariate.png', dpi=500)
plt.show()