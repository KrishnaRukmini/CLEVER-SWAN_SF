import pandas as pd
import os


def List_Of_Files(dir_name):
  listoffiles=[x[2] for x in os.walk(dir_name)]
  return listoffiles


def under_sampling(path):
  F_T = ["FL", "NF"]
  count=0
  partition_data = pd.DataFrame()
  for dir in F_T:
    files = List_Of_Files(path+dir+'/')
    for file in files[0]:
      data = pd.read_csv(path+dir+'/'+file, sep='\t')
      data.drop('Unnamed: 0', axis =1,inplace=True)
      #print(data.head())
      partition_data = pd.concat([partition_data,data], axis=0)
      count += 1
      print(count)
    partition_data.to_csv("/content/partition_2_df", sep='\t')
  print(partition_data)


path = "/content/Cleaned_data_partition_2/"
under_sampling(path)