import Clever_ranking
from sklearn.cluster import KMeans
from scipy.cluster.vq import vq
from numpy import linalg as la
import pandas as pd


def clever_cluster(data, col, k):
    """
        Clever cluster - Clustering using kmeans method to group the similar variables
        together and select the least redundant variables

        :param data_path: path to the loadings data
        :param k: No. of desired or required variables in Truncated data
        :return: Gives the selected top ranked variable names
    """
    #data, col = Sample_mvts.Compute_DCPCS(data_path)


    pair = []
    selected_var = []
    for x in range(20):
        kmeans = KMeans(n_clusters=k, random_state=123).fit(data.T)
    labels = kmeans.labels_
    # print(kmeans.cluster_centers_)
    closest, distances = vq(kmeans.cluster_centers_, data.T)
    closest_variable = closest.tolist()
    # print(closest, distances)

    for i, sv in enumerate(closest_variable):
        val = la.norm(data[str(sv)])
        pair.append([str(sv), val])
    Clever_ranking.Sort(pair)
    for ind, x in enumerate(pair):
        selected_var.append(x[0])
    print(selected_var)
    for ind, close in enumerate(selected_var):
        selected_var[ind] = col[int(close)]
    return selected_var, labels


"""
data_path = 'C:/Users/Krishna Rukmini/Downloads/partition1_instances/partition1_instances (1).tar/partition1/FL/'
colmn, labels = clever_cluster(data_path, 15)
print(colmn)



data = pd.read_csv("../Initial_commit_mvts/Data/DCPC_CSV.csv", sep='\t')
data.drop(["Unnamed: 0"], axis=1, inplace=True)
col = {1 : 'TOTUSJH', 2 : 'TOTBSQ', 3 : 'TOTPOT', 4 : 'TOTUSJZ',
        5 : 'ABSNJZH', 6 : 'SAVNCPP', 7 : 'USFLUX', 8 : 'TOTFZ',
        9 : 'MEANPOT', 10 : 'EPSZ', 11 : 'MEANSHR', 12 : 'SHRGT45',
        13 : 'MEANGAM', 14 : 'MEANGBT', 15 : 'MEANGBZ', 16 : 'MEANGBH',
        17 : 'MEANJZH', 18 : 'TOTFY', 19 : 'MEANJZD', 20 : 'MEANALP',
        21 : 'TOTFX', 22 : 'EPSY', 23 : 'R_VALUE', 24 : 'EPSX'}
selected_var, labels = clever_cluster(data, col, 15)
print(selected_var)

clustering_univariate_df = pd.DataFrame()
clustering_univariate_df['rank_list_fss'] = selected_var
clustering_univariate_df.to_csv("../Initial_commit_mvts/Results/clustering_univariate.csv", sep='\t')
"""